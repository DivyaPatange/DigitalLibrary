<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
        </div>
    </div>
</footer><?php /**PATH C:\wamp\www\Iceico\laravel\vimladevi\resources\views/auth/authLayouts/footer.blade.php ENDPATH**/ ?>