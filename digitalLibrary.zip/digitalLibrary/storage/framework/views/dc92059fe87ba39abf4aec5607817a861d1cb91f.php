<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('adminAsset/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('adminAsset/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('adminAsset/js/sb-admin-2.min.js')); ?>"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('adminAsset/vendor/chart.js/Chart.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('adminAsset/js/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/js/demo/chart-pie-demo.js')); ?>"></script><?php /**PATH F:\project\www\Iceico\laravel\eLibrary\resources\views/auth/authLayouts/scripts.blade.php ENDPATH**/ ?>