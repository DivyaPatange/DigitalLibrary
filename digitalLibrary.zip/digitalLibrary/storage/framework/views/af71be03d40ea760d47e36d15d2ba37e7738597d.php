<?php $__env->startSection('title', 'Books'); ?>
<?php $__env->startSection('customcss'); ?>

<link href="<?php echo e(asset('adminAsset/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<script>
$(function(){
    $('#download').hide();
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block mt-4">
    <button type="button" class="close" data-dismiss="alert">×</button>	
          <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>
  <?php if($message = Session::get('danger')): ?>
  <div class="alert alert-danger alert-block mt-4">
    <button type="button" class="close" data-dismiss="alert">×</button>	
          <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Books</h1>
  
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Book List</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Sr. No.</th>
              <th>Category Name</th>
              <th>Book Name</th>
              <th>Author Name</th>
              <th>Book Pdf</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>Sr. No.</th>
              <th>Category Name</th>
              <th>Book Name</th>
              <th>Author Name</th>
              <th>Book Pdf</th>
            </tr>
          </tfoot>
          <tbody>
          <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $categoryName = DB::table('categories')->where('id', $b->cat_id)->first();
          ?>
            <tr>
              <td><?php echo e(++$key); ?></td>
              <td><?php if($categoryName): ?> <?php echo e($categoryName->category); ?>  <?php endif; ?></td>
              <td><?php echo e($b->book_name); ?></td>
              <td><?php echo e($b->author_name); ?></td>
              <td>
              
                <a href="<?php echo e(route('book.view', $b->id)); ?>" id="download" class="btn btn-success btn-circle">
                  <i class="fas fa-file"></i>
                </a>
              </td>
            </tr>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('adminAsset/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('adminAsset/js/demo/datatables-demo.js')); ?>"></script>
<script>
$(document).ready(function() {
        $('#dataTable').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authLayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Iceico\laravel\digitalLibrary\resources\views/auth/books/show.blade.php ENDPATH**/ ?>