<?php $__env->startSection('title', 'Edit Video'); ?>
<?php $__env->startSection('customcss'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block mt-4">
    <button type="button" class="close" data-dismiss="alert">×</button>	
          <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>
  <?php if($message = Session::get('danger')): ?>
  <div class="alert alert-danger alert-block mt-4">
    <button type="button" class="close" data-dismiss="alert">×</button>	
          <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>
  <!-- Page Heading -->
  <div class="row justify-content-center">
    <div class="col-lg-6">
      <!-- Basic Card Example -->
      <div class="card shadow mb-4">
        <div class="card-header">
          Edit Video
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('admin.videos.update', $video->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?>
            <div class="form-group ">
              <input type="text" class="form-control form-control-user <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="exampleInputName" placeholder="Title" value="<?php echo e($video->title); ?>">
              <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group ">
              <input type="file" class="form-control form-control-user <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="video" id="exampleInputName">
              <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group ">
            <?php if($video->video): ?>
                    <a href="<?php echo e(URL::to('/')); ?>/Video/<?php echo e($video->video); ?>" target="_blank"> Click to view</a>
                  <?php endif; ?>
                  <input type="hidden" name="hidden_image" value="<?php echo e($video->video); ?>">
                  </div>
            <button type="submit" class="btn btn-primary btn-user btn-block">
              Update
            </button>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('adminAsset/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('adminAsset/js/demo/datatables-demo.js')); ?>"></script>
<script>
$(document).ready(function() {
        $('#dataTable').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authLayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Iceico\laravel\digitalLibrary\resources\views/auth/videos/edit.blade.php ENDPATH**/ ?>