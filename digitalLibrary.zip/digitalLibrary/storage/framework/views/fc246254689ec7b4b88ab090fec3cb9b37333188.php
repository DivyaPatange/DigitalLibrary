<?php $__env->startSection('title', 'Books'); ?>
<?php $__env->startSection('customcss'); ?>

<link href="<?php echo e(asset('adminAsset/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block mt-4">
    <button type="button" class="close" data-dismiss="alert">×</button>	
          <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>
  <?php if($message = Session::get('danger')): ?>
  <div class="alert alert-danger alert-block mt-4">
    <button type="button" class="close" data-dismiss="alert">×</button>	
          <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Books</h1>
  <div class="row justify-content-center">
    <div class="col-lg-12">
      <!-- Basic Card Example -->
      <div class="card shadow mb-4">
        <div class="card-body">
        <iframe src="<?php echo e(URL::to('/')); ?>/Pdf/<?php echo e($book->book_pdf); ?>#toolbar=0&navpanes=0&scrollbar=0" title="PDF in an i-Frame" frameborder="0" scrolling="auto" style="width:100%; height:500px"></iframe>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('adminAsset/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminAsset/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('adminAsset/js/demo/datatables-demo.js')); ?>"></script>
<script>
$(document).ready(function() {
        $('#dataTable').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authLayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\www\Iceico\laravel\eLibrary\resources\views/auth/books/view.blade.php ENDPATH**/ ?>